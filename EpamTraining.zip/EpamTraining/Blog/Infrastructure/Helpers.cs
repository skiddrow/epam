﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Blog.Infrastructure
{
    public static class Helpers
    {
        public static MvcHtmlString TestItem(this HtmlHelper helper, string Formulation, string Answer1, string Answer2, string Answer3)
        {
            TagBuilder cont = new TagBuilder("div");
            TagBuilder title = new TagBuilder("h4");
            title.SetInnerText(Formulation);
            //TagBuilder list = new TagBuilder("ul");
            title.InnerHtml += string.Format("<p><label><input type=\"radio\" name=\"testAnswer\" value=\"{0}\" /> {0}</label></p>", Answer1);
            title.InnerHtml += string.Format("<p><label><input type=\"radio\" name=\"testAnswer\" value=\"{0}\" /> {0}</label></p>", Answer2);
            title.InnerHtml += string.Format("<p><label><input type=\"radio\" name=\"testAnswer\" value=\"{0}\" /> {0}</label></p>", Answer3);

            cont.InnerHtml = title.InnerHtml;
            //cont.InnerHtml += list.InnerHtml;

            return new MvcHtmlString(cont.InnerHtml);
        }
    }
}