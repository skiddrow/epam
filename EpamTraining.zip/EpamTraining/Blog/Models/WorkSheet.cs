﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Blog.Models
{
    public static class WorkSheet
    {
        public static string Name { get; set; }
        public static string Surame { get; set; }
        public static string Sex { get; set; }
        public static DateTime? DateOfBirth { get; set; }
        public static bool? IsInterested { get; set; }
        public static List<string> Anwsers;

        //public WorkSheet(string name, string surname, string sex, DateTime date, bool isIntersted)
        //{
        //    Name = name;
        //    Surame = surname;
        //    Sex = sex;
        //    DateOfBirth = date;
        //    IsInterested = isIntersted;
        //}
    }
}
