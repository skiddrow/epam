﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Blog.Models
{
    [Serializable]
    public class Reveiw
    {
        public string Name { get; set; }
        public string Text { get; set; }
        public DateTime Date { get; set; }

        public Reveiw() { }

        public Reveiw(string Name, string Text, DateTime Date)
        {
            this.Name = Name;
            this.Text = Text;
            this.Date = Date;
        }
    }
}