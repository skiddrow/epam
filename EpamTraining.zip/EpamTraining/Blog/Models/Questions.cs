﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Blog.Models
{
    public static class Questions
    {
        public static List<Question> QuestionList { get; set; }
        public static int Result { get; set; }

        static Questions()
        {
            QuestionList = new List<Question>
            {              
                new Question("Вопрос №1: Какой из этих принципов не относится к постулатам ООП?","Верификация","Инкапсуляцмя","Полиморфизм","Верификация"),
                new Question("Вопрос №2: Где хранятся экземпляры классов в C#?","В стеке","В куче","В очереди","В куче"),
                new Question("Вопрос №3: Выберите неверное утверждение","Структуру нельзя пометить атрибутом","Downcast невозможен без предварительного Upcast'а","В C# существует множественное наследование","В C# существует множественное наследование")
            };
            Result = 0;
        }
    }

    public class Question
    {
        public string Formulation { get; set; }
        public string Answer1 { get; set; }
        public string Answer2 { get; set; }
        public string Answer3 { get; set; }
        public string CorrectAnswer { get; set; }

        public Question(string Formulation, string Answer1, string Answer2, string Answer3, string CorrectAnswer)
        {
            this.Formulation = Formulation;
            this.Answer1 = Answer1;
            this.Answer2 = Answer2;
            this.Answer3 = Answer3;
            this.CorrectAnswer = CorrectAnswer;
        }
    }

    [Serializable]
    struct MyStruct
    {
        
    }
}