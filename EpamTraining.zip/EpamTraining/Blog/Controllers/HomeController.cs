﻿using Blog.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml.Serialization;

namespace Blog.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            List<Models.Blog> Blogs = new List<Models.Blog>();

            XmlSerializer formatter = new XmlSerializer(typeof(List<Models.Blog>));

            using (FileStream fs = new FileStream("C:\\EPAM\\ASP.NET MVC training\\Pr1\\EpamTraining\\Blog\\App_Data\\Blogs.xml", FileMode.OpenOrCreate))
            {
                if (fs.Length == 0)
                {
                    Blogs = new List<Models.Blog>();
                }
                else
                {
                    Blogs = (List<Models.Blog>)formatter.Deserialize(fs);
                }
            }

            if (Blogs.Count != 0)
            {
                ViewBag.Res = true;
                ViewBag.Blogs = Blogs;
            }
            else
            {
                ViewBag.Res = false;
            }
            return View();
        }

        [HttpGet]
        public ActionResult Guest()
        {
            List<Models.Reveiw> newRevs;

            XmlSerializer formatter = new XmlSerializer(typeof(List<Models.Reveiw>));

            using (FileStream fs = new FileStream("C:\\EPAM\\ASP.NET MVC training\\Pr1\\EpamTraining\\Blog\\App_Data\\Reviews.xml", FileMode.OpenOrCreate))
            {
                if (fs.Length == 0)
                {
                    newRevs = new List<Models.Reveiw>();
                }
                else
                {
                    newRevs = (List<Models.Reveiw>)formatter.Deserialize(fs);
                }
            }

            ViewBag.Revs = newRevs;
            return View();
        }

        [HttpPost]
        public ActionResult Guest(string Name, string Review)
        {
            Models.Reveiw rev = new Models.Reveiw(Name, Review, DateTime.Now.Date);
            List<Models.Reveiw> newRevs;

            XmlSerializer formatter = new XmlSerializer(typeof(List<Models.Reveiw>));

            using (FileStream fs = new FileStream("C:\\EPAM\\ASP.NET MVC training\\Pr1\\EpamTraining\\Blog\\App_Data\\Reviews.xml", FileMode.OpenOrCreate))
            {
                if (fs.Length == 0)
                {
                    newRevs = new List<Models.Reveiw>();
                }
                else
                {
                    newRevs = (List<Models.Reveiw>)formatter.Deserialize(fs);
                }
            }

            newRevs.Add(rev);

            using (FileStream fs = new FileStream("C:\\EPAM\\ASP.NET MVC training\\Pr1\\EpamTraining\\Blog\\App_Data\\Reviews.xml", FileMode.OpenOrCreate))
            {
                formatter.Serialize(fs, newRevs);
            }

            return RedirectToAction("Guest");
        }

        public ActionResult Worksheet(string Name, string Surname, DateTime? Date, string Sex, Nullable<bool> IsInteresting, int? QuestionNumber, string testAnswer)
        {
            ViewBag.IsTestCompleted = false;

            if (Request.RequestType == "GET")
            {
                Questions.Result = 0;

                return View();
            }
            else if (Request.RequestType == "POST")
            {
                if (testAnswer != null && testAnswer == Questions.QuestionList[QuestionNumber.Value].CorrectAnswer)
                {
                    Questions.Result++;
                }

                WorkSheet.Name = Name;
                WorkSheet.Surame = Surname;
                WorkSheet.DateOfBirth = Date;
                WorkSheet.Sex = Sex;
                WorkSheet.IsInterested = IsInteresting;
                QuestionNumber = QuestionNumber ?? -1;
                QuestionNumber++;
                ViewBag.QuestionNumber = QuestionNumber;

                if (QuestionNumber >= Questions.QuestionList.Count)
                {
                    ViewBag.IsTestCompleted = true;
                    ViewBag.Res = Questions.Result;
                    ViewBag.Count = QuestionNumber--;

                    return View();
                }

                return View(Questions.QuestionList[QuestionNumber.Value]);
            }
            else
            {
                throw new Exception();
            }
        }
    }
}